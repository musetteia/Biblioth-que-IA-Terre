#!/usr/bin/env python3
"""Affiche un BNA (formulaire Adobe XFA) comme Adobe le ferait et en fait une capture PNG, grâce à pdf.js.
Usage : python3 -I rendu_bna.py <bna.pdf> <sortie.png> [--dossier-pdfjs DOSSIER]
Prérequis (installés une fois par l'utilisateur, le script ne contacte aucun service) :
  pdfjs-dist@4.10.38 dans le dossier pdf.js (par défaut ~/.cache/rendu_bna) : npm install pdfjs-dist@4.10.38 ;
  Python playwright avec Chromium.
Le BNADN n'occupe que le bas de la page : c'est normal."""
import sys, os, subprocess, time, shutil, socket, argparse

HTML = """<!doctype html><html><head><meta charset="utf-8">
<link rel="stylesheet" href="node_modules/pdfjs-dist/web/pdf_viewer.css">
<style>body{margin:0;background:#fff}.page{position:relative;margin:0 auto}</style></head><body><div id="out"></div>
<script type="module">
import * as pdfjs from './node_modules/pdfjs-dist/build/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc = './node_modules/pdfjs-dist/build/pdf.worker.mjs';
window.rendre = async (url) => { const doc = await pdfjs.getDocument({ url, enableXfa: true }).promise; const out = document.getElementById('out');
  for (let i = 1; i <= doc.numPages; i++) { const page = await doc.getPage(i), vp = page.getViewport({ scale: 1.3 }), div = document.createElement('div');
    div.className = 'page xfaLayer'; div.style.width = vp.width + 'px'; div.style.height = vp.height + 'px'; out.append(div);
    pdfjs.XfaLayer.render({ viewport: vp.clone({ dontFlip: true }), div, xfaHtml: await page.getXfa(), annotationStorage: doc.annotationStorage,
      linkService: { getDestinationHash: () => '#', addLinkAttributes: () => {} }, intent: 'display' }); }
  return [doc.numPages, doc.isPureXfa]; };
window.pret = true;
</script></body></html>"""

a = argparse.ArgumentParser(); a.add_argument('pdf'); a.add_argument('png'); a.add_argument('--dossier-pdfjs', default=os.path.expanduser('~/.cache/rendu_bna'))
a = a.parse_args(); D = a.dossier_pdfjs; os.makedirs(D + '/doc', exist_ok=True)
if not os.path.exists(D + '/node_modules/pdfjs-dist/build/pdf.mjs'):
    sys.exit("pdf.js introuvable dans %s. Installez-le une fois vous-même :\n  cd %s && npm init -y && npm install pdfjs-dist@4.10.38\n"
             "ou indiquez un dossier existant avec --dossier-pdfjs. Ce script ne télécharge rien." % (D, D))
open(D + '/rendu.html', 'w', encoding='utf-8').write(HTML); shutil.copy(a.pdf, D + '/doc/x.pdf')
s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(port), '-b', '127.0.0.1', '-d', D], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        br = p.chromium.launch(); pg = br.new_page(viewport={'width': 1000, 'height': 1400}); err = []
        pg.on('pageerror', lambda e: err.append(str(e)[:200]))
        pg.goto(f'http://127.0.0.1:{port}/rendu.html'); pg.wait_for_function('window.pret === true')
        n, xfa = pg.evaluate("rendre('doc/x.pdf')"); pg.wait_for_timeout(1500)
        pg.screenshot(path=a.png, full_page=True); br.close()
    print('pages :', n, '| formulaire XFA :', xfa, '| erreurs :', err or 'aucune', '| capture :', a.png)
finally:
    srv.terminate(); os.remove(D + '/doc/x.pdf')
