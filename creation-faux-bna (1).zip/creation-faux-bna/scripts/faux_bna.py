#!/usr/bin/env python3
"""Création de faux BNA (BNAPN / BNADN) de test, à partir des maîtres fictifs du skill.

Commandes :
  lot      --n N [--grades CPL:10,SGT:5] [--annee 2026] [--unite FIC] [--debut 1] --sortie DOSSIER
           -> N paires PN/DN vierges + identites.xlsx (+ --modele modele_notation.xlsx pour pré-remplir un classeur)
  maitre   --pn VRAI_PN.pdf --dn VRAI_DN.pdf --sortie DOSSIER
           -> nouveaux maîtres fictifs à partir de vrais BNA (formulaire mis à jour). Données réelles effacées.
  controle --reference VRAI.pdf [...] --fichiers F.pdf [...]
           -> vérifie qu'aucune valeur des vrais BNA ne subsiste dans les faux (fichiers bruts et flux décompressés).

Dépendances : pypdf, lxml, openpyxl. qpdf (facultatif) compacte et purge les objets orphelins.
Toujours lancer avec : python3 -I faux_bna.py ...
"""
import argparse, os, re, sys, zlib, shutil, subprocess, tempfile, unicodedata
from lxml import etree
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, ArrayObject, TextStringObject, DecodedStreamObject

XD = '{http://www.xfa.org/schema/xfa-data/1.0/}'
TPL = '{http://www.xfa.org/schema/xfa-template/2.7/}'
ICI = os.path.dirname(os.path.abspath(__file__))
MAITRES = os.path.join(os.path.dirname(ICI), 'maitres')
MAITRE_PN, MAITRE_DN = os.path.join(MAITRES, 'BNAPN_maitre_FICTIF.pdf'), os.path.join(MAITRES, 'BNADN_maitre_FICTIF.pdf')
MARQUE = '(FICTIF)'

# Structure du formulaire : valeurs conservées telles quelles (aucune donnée personnelle)
GARDE = {'ARMEE', 'CORPS', 'YYCORPS', 'GRADE', 'YYGRADE', 'PERSG', 'PERSK', 'FORMN', 'DOCTY', 'INFTY', 'ISTAT',
         'SCALE_ID', 'SCALE_TEXT', 'NOT_RATED', 'NO_NOTE', 'APP_OTYPE', 'APP_OBJID', 'APP_STEXT', 'APP_INPUT', 'OTYPE',
         'SLEVL', 'RANK', 'EVALUAT', 'CALC_RESULT', 'PARENT', 'CHILD', 'BROTHER', 'SEQNR', 'FORMULAIRE', 'PLVAR', 'MANDT'}
# Champs affichés : valeurs fictives lisibles
AFFICHES = {'SACHN': 'FICTIF', 'STEXT': 'UNITÉ FICTIVE', 'VILLE_FE': 'VILLE FICTIVE', 'TPS_OA': '1 an',
            'TPS_RSV': '', 'ESP': '', 'YYPN2': MARQUE, 'YYPN3': '', 'LIB_EIP': 'FICTIF', 'OA_STEXT': 'UNITÉ FICTIVE'}
DATE = re.compile(r'^\d{4}-\d{2}-\d{2}$')
NOMS = ['MARTIN', 'BERNARD', 'THOMAS', 'PETIT', 'ROBERT', 'RICHARD', 'DURAND', 'DUBOIS', 'MOREAU', 'LAURENT', 'SIMON', 'MICHEL',
        'LEFEBVRE', 'LEROY', 'ROUX', 'DAVID', 'BERTRAND', 'MOREL', 'FOURNIER', 'GIRARD', 'BONNET', 'DUPONT', 'LAMBERT', 'FONTAINE',
        'ROUSSEAU', 'VINCENT', 'MULLER', 'LEFEVRE', 'FAURE', 'ANDRE', 'MERCIER', 'BLANC', 'GUERIN', 'BOYER', 'GARNIER', 'CHEVALIER',
        'FRANCOIS', 'LEGRAND', 'GAUTHIER', 'GARCIA', 'PERRIN', 'ROBIN', 'CLEMENT', 'MORIN', 'NICOLAS', 'HENRY', 'ROUSSEL', 'MATHIEU',
        'GAUTIER', 'MASSON']
PRENOMS_M = ['Lucas', 'Hugo', 'Louis', 'Jules', 'Adam', 'Arthur', 'Nathan', 'Paul', 'Léo', 'Tom', 'Théo', 'Noah', 'Enzo', 'Maxime', 'Antoine']
PRENOMS_F = ['Chloé', 'Emma', 'Léa', 'Manon', 'Camille', 'Sarah', 'Inès', 'Julie', 'Laura', 'Clara']
SO = {'SGT', 'MDL', 'SCH', 'MDC', 'ADJ', 'ADC', 'MJR'}


def paquets(chemin):
    x = PdfReader(chemin).trailer['/Root']['/AcroForm']['/XFA']
    return {str(x[i]): x[i + 1].get_object().get_data() for i in range(0, len(x), 2)}


def ecrire_pdf(src, dest, nouveaux, retirer=('form',), sans_perms=True):
    """Réécrit src en remplaçant les paquets XFA donnés (nom -> octets), retire 'form' (copie des valeurs)."""
    w = PdfWriter(clone_from=PdfReader(src)); root = w._root_object
    af = root['/AcroForm'].get_object(); xfa = af['/XFA']; nv = ArrayObject()
    for i in range(0, len(xfa), 2):
        nom = str(xfa[i])
        if nom in retirer: continue
        if nom in nouveaux:
            s = DecodedStreamObject(); s.set_data(nouveaux[nom]); nv += [TextStringObject(nom), w._add_object(s.flate_encode())]
        else: nv += [xfa[i], xfa[i + 1]]
    af[NameObject('/XFA')] = nv
    if sans_perms and '/Perms' in root: del root['/Perms']   # signature Adobe Reader : invalide après modification
    tmp = dest + '.tmp'
    with open(tmp, 'wb') as f: w.write(f)
    if shutil.which('qpdf'):
        r = subprocess.run(['qpdf', '--object-streams=generate', '--remove-unreferenced-resources=yes', tmp, dest], capture_output=True)
        if r.returncode not in (0, 3): raise RuntimeError(r.stderr.decode()[:300])
        os.remove(tmp)
    else: os.replace(tmp, dest)


def marquer_template(tpl, type_):
    """Bandeau « DOCUMENT FICTIF » : titre du PN complété ; bandeau ajouté en tête du DN (qui n'en a pas)."""
    t = etree.fromstring(tpl)
    rouge = '<fill><color value="200,0,0"/></fill>'
    if type_ == 'PN':
        d = [e for e in t.iter(TPL + 'draw') if e.get('name') == 'Titre' and 'BULLETIN' in ''.join(e.itertext())]
        if d and 'FICTIF' not in ''.join(d[0].itertext()):
            d = d[0]; d.set('x', '33.6mm'); d.set('w', '130mm')
            txt = d.find(TPL + 'value').find(TPL + 'text'); txt.text = 'BULLETIN DE NOTATION ANNUELLE — DOCUMENT FICTIF'
            f = d.find(TPL + 'font'); f.append(etree.fromstring(rouge.replace('<fill>', '<fill xmlns="%s">' % TPL[1:-1])))
    else:
        page = [e for e in t.iter(TPL + 'subform') if e.get('name') == 'Page'][0]
        if not any(e.get('name') == 'BandeauFictif' for e in page):
            ns = TPL[1:-1]; fnt = '<font size="11pt" typeface="Arial" weight="bold">%s</font>' % rouge.replace('<fill>', '<fill xmlns="%s">' % ns)
            for nom, ref, x, w in (('NomFictif', 'IM_P0002.NACHN', '50mm', '55mm'), ('PrenomFictif', 'IM_P0002.VORNA', '106mm', '45mm')):
                page.insert(0, etree.fromstring('<field xmlns="%s" name="%s" x="%s" y="229mm" w="%s" h="7mm" access="readOnly"><ui><textEdit/></ui>%s'
                    '<para vAlign="middle"/><bind match="dataRef" ref="%s"/></field>' % (ns, nom, x, w, fnt, ref)))
            page.insert(0, etree.fromstring('<draw xmlns="%s" name="Militaire" x="0mm" y="229mm" w="49mm" h="7mm"><ui><textEdit/></ui><value><text>Militaire (FICTIF) :</text></value>%s<para hAlign="right" vAlign="middle"/></draw>' % (ns, fnt)))
            page.insert(0, etree.fromstring(
                '<draw xmlns="%s" name="BandeauFictif" x="0mm" y="219mm" w="197.3mm" h="10mm"><ui><textEdit/></ui>'
                '<value><text>BNADN — DOCUMENT FICTIF — TEST UNIQUEMENT</text></value>'
                '<font size="14pt" typeface="Arial" weight="bold">%s</font><para hAlign="center" vAlign="middle"/></draw>'
                % (TPL[1:-1], rouge.replace('<fill>', '<fill xmlns="%s">' % TPL[1:-1]))))
    return etree.tostring(t, encoding='utf-8', xml_declaration=False)


def anonymiser(xml, sensibles):
    """Liste blanche : seule la structure reste ; tout le reste est effacé ou remplacé par une valeur fictive."""
    d = etree.fromstring(xml); rec = d.find(XD + 'data')[0]; qsr = rec.find('IT_HRT1045_QSR')
    for e in rec.iter():
        if len(e) or not (e.text or '').strip(): continue
        v, t = e.text.strip(), e.tag
        if t in GARDE or (t == 'OBJID' and qsr is not None and qsr in e.iterancestors()): continue
        if len(v) >= 3 and t not in ('RATING', 'VALIDE', 'ANNEE', 'GESCH', 'ANRED'): sensibles.add(v)
        if t == 'RATING': e.text = '0.000'
        elif t == 'STRING': e.text = ''
        elif t in AFFICHES: e.text = AFFICHES[t]
        elif DATE.match(v): e.text = '2025-07-01'
        elif re.fullmatch(r'\d+', v): e.text = '9' * len(v) if len(v) >= 5 else '0' * len(v)
        else: e.text = 'FICTIF'
    ids = sorted({v for v in sensibles if re.fullmatch(r'\d{5,}', v)})   # identifiants recopiés dans la structure
    for e in rec.iter():
        if len(e) == 0 and e.text:
            for v in ids:
                if v in e.text: e.text = e.text.replace(v, '9' * len(v))
    return etree.tostring(d, encoding='utf-8')


def personnaliser(xml, m):
    d = etree.fromstring(xml); rec = d.find(XD + 'data')[0]
    for tag, val in [('NACHN', m['nom']), ('VORNA', m['prenom']), ('NCHMC', m['nom']), ('VNAMC', m['prenom'].upper()),
                     ('GESCH', m['genre']), ('ANRED', m['genre']), ('YYPN2', MARQUE)]:
        for e in rec.iter(tag): e.text = val
    for e in rec.iter('ENAME'): e.text = m['prenom'] + ' ' + m['nom'] + ' ' + MARQUE
    for e in rec.iter('SNAME'): e.text = m['nom'] + ' ' + m['prenom'].upper()
    # faux numéros (matricule, NI, identifiants SAP) : uniques par militaire, longueur d'origine conservée
    if m['k']:   # le maître (k = 0) garde ses repères 999… ; chaque faux reçoit les siens
        for e in rec.iter():
            if len(e) == 0 and e.text and re.fullmatch(r'9{5,}', e.text.strip()):
                n = len(e.text.strip()); e.text = m['pernr'][-n:].zfill(n) if e.tag in ('PERNR', 'OBJID_BA') else ('8' + str(m['k']).zfill(n - 1))[-n:]
    for tag, val in [('ANNEE', m['annee']), ('VALIDE', '0'), ('GRDC_NOT', m['grade'])] + ([('OBJID_BA', m['pernr'])] if m['k'] else []):
        e = rec.find(tag)
        if e is not None: e.text = val
    t = rec.find('TEXTE')
    if t is not None and m['type'] == 'PN' and len(t) > 56:   # millésime affiché
        s = t[56].find('STRING')
        if s is not None: s.text = m['annee']
    return etree.tostring(d, encoding='utf-8')


def sans_accent(s): return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')


def cmd_maitre(a):
    os.makedirs(a.sortie, exist_ok=True); sens = set()
    for src, typ, dest in ((a.pn, 'PN', 'BNAPN_maitre_FICTIF.pdf'), (a.dn, 'DN', 'BNADN_maitre_FICTIF.pdf')):
        P = paquets(src)
        if 'datasets' not in P or 'template' not in P: sys.exit(src + " : pas un formulaire BNA (XFA)")
        ds = anonymiser(P['datasets'], sens)
        ds = personnaliser(ds, dict(nom='MAITRE', prenom='Fictif', genre='1', grade='CPL', pernr='99999999', annee='2026', k=0, type=typ))
        ecrire_pdf(src, os.path.join(a.sortie, dest), {'datasets': ds, 'template': marquer_template(P['template'], typ)})
    gabarit = b''.join(v for k, v in paquets(a.pn).items() if k not in ('datasets', 'form')) + \
              b''.join(v for k, v in paquets(a.dn).items() if k not in ('datasets', 'form'))
    sens = {v for v in sens if len(v) >= 4 and not set(v) <= set('0.') and v.encode() not in gabarit and v != 'Armée de Terre'}
    for f in ('BNAPN_maitre_FICTIF.pdf', 'BNADN_maitre_FICTIF.pdf'):
        n = controler(os.path.join(a.sortie, f), sens); print(f, ': valeurs réelles retrouvées =', n)
        if n: sys.exit('ÉCHEC : le maître contient encore des données réelles, ne pas l\'utiliser')
    print(len(sens), 'valeurs réelles contrôlées. Maîtres prêts dans', a.sortie)


def controler(chemin, sensibles):
    b = open(chemin, 'rb').read(); flux = [b]
    for mt in re.finditer(rb'stream\r?\n', b):
        e = b.find(b'endstream', mt.end())
        try: flux.append(zlib.decompress(b[mt.end():e].rstrip(b'\r\n')))
        except Exception: pass
    n = 0
    for v in sensibles:
        for enc in {v.encode('utf-8'), v.encode('latin-1', 'ignore'), v.encode('utf-16-be'), v.upper().encode(), v.lower().encode()}:
            if len(enc) >= 3 and any(enc in f for f in flux): n += 1; break
    return n


def cmd_controle(a):
    sens = set()
    for r in a.reference:
        P = paquets(r); gab = b''.join(v for k, v in P.items() if k not in ('datasets', 'form'))
        for e in etree.fromstring(P['datasets']).iter():
            v = (e.text or '').strip()
            if len(e) == 0 and len(v) >= 4 and not set(v) <= set('0.') and v.encode() not in gab and e.tag not in GARDE and v != 'Armée de Terre': sens.add(v)
    ko = 0
    for f in a.fichiers:
        n = controler(f, sens); ko += n; print(os.path.basename(f), ': valeurs réelles retrouvées =', n)
    print(len(sens), 'valeurs réelles contrôlées ;', 'AUCUNE fuite' if not ko else 'FUITE DÉTECTÉE')
    sys.exit(1 if ko else 0)


def cmd_lot(a):
    import openpyxl
    os.makedirs(a.sortie, exist_ok=True)
    grades = []
    if a.grades:
        for g in a.grades.split(','):
            gr, nb = g.split(':'); grades += [gr.strip().upper()] * int(nb)
    else: grades = ['CPL'] * a.n
    grades = grades[:a.n] + ['CPL'] * max(0, a.n - len(grades))
    PN, DN = paquets(MAITRE_PN)['datasets'], paquets(MAITRE_DN)['datasets']
    lignes, vus = [], set()
    for i in range(a.n):
        k = a.debut + i; genre = '2' if k % 5 == 0 else '1'
        nom = NOMS[k % len(NOMS)] + ('' if k < len(NOMS) else str(k // len(NOMS) + 1).translate(str.maketrans('0123456789', 'ABCDEFGHIJ')))
        prenom = (PRENOMS_F if genre == '2' else PRENOMS_M)[k % (len(PRENOMS_F) if genre == '2' else len(PRENOMS_M))]
        m = dict(nom=nom, prenom=prenom, genre=genre, grade=grades[i], pernr=str(91000000 + k), annee=a.annee, k=k)
        base = f"{k:02d}_{a.annee}_BNA{{}}_{m['grade']}_{sans_accent(nom.capitalize())}_{a.unite}.pdf"
        for typ, src, ds in (('PN', MAITRE_PN, PN), ('DN', MAITRE_DN, DN)):
            m['type'] = typ
            ecrire_pdf(src, os.path.join(a.sortie, base.format(typ)), {'datasets': personnaliser(ds, m)}, retirer=('form',), sans_perms=True)
        lignes.append([nom, prenom, m['grade'], 'F' if genre == '2' else 'M', 'SO' if m['grade'] in SO else 'MDR', m['pernr'], base.format('PN'), base.format('DN')])
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'Identités fictives'
    ws.append(['Nom réel', 'Prénom', 'Grade', 'Genre', 'Catégorie', 'Matricule (fictif)', 'Fichier BNAPN', 'Fichier BNADN'])
    for l in lignes: ws.append(l)
    wb.save(os.path.join(a.sortie, 'identites.xlsx'))
    if a.modele:
        wb = openpyxl.load_workbook(a.modele); ws = wb['Notations']; h = [c.value for c in ws[1]]
        col = {n: h.index(n) + 1 for n in ('Nom réel', 'Prénom', 'Grade', 'Genre', 'Catégorie')}
        for r, l in enumerate(lignes, start=2):
            for n, v in zip(('Nom réel', 'Prénom', 'Grade', 'Genre', 'Catégorie'), l[:5]): ws.cell(r, col[n]).value = v
        wb.save(os.path.join(a.sortie, 'notation_lot_fictif.xlsx'))
    print(a.n, 'militaires fictifs ->', 2 * a.n, 'PDF dans', a.sortie)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); s = p.add_subparsers(dest='cmd', required=True)
    l = s.add_parser('lot'); l.add_argument('--n', type=int, required=True); l.add_argument('--grades'); l.add_argument('--annee', default='2026')
    l.add_argument('--unite', default='FIC_TST'); l.add_argument('--debut', type=int, default=1); l.add_argument('--modele'); l.add_argument('--sortie', required=True)
    m = s.add_parser('maitre'); m.add_argument('--pn', required=True); m.add_argument('--dn', required=True); m.add_argument('--sortie', required=True)
    c = s.add_parser('controle'); c.add_argument('--reference', nargs='+', required=True); c.add_argument('--fichiers', nargs='+', required=True)
    a = p.parse_args(); {'lot': cmd_lot, 'maitre': cmd_maitre, 'controle': cmd_controle}[a.cmd](a)
