// Application d'essai : un appel à Claude (sample) et un enregistrement (db). Aucun appel à un autre site.
const use = n => (window.claude && typeof window.claude.use === 'function')
  ? Promise.resolve(window.claude.use(n)).catch(() => null) : Promise.resolve(null);
const etat = document.getElementById('etat');
const bouton = document.getElementById('demander');
const reponse = document.getElementById('reponse');
const liste = document.getElementById('liste');
let sm = null, db = null;

function afficher(docs) {
  liste.textContent = '';
  docs.forEach(d => { const li = document.createElement('li'); li.textContent = d.data().phrase; liste.appendChild(li); });
}

(async () => {
  sm = await use('sample');
  db = await use('db');
  etat.textContent = 'Appel à Claude : ' + (sm ? 'disponible' : 'indisponible') + ' · Base de données : ' + (db ? 'disponible' : 'indisponible');
  if (!sm) { bouton.disabled = true; reponse.textContent = "Claude n'est pas joignable : ouvrez cette page comme artefact dans Claude."; }
  if (db) { db.collection('essais').orderBy('createdAt', 'desc').limit(5).onSnapshot(snap => afficher(snap.docs)); }
})();

bouton.addEventListener('click', async () => {
  if (!sm) { return; }
  bouton.disabled = true; reponse.textContent = 'Claude réfléchit…';
  try {
    const r = await sm.json('Réponds en JSON {"phrase": "..."} avec une phrase courte et amicale (une ligne) qui confirme que le circuit d\'essai de la Bibliothèque IA Terre fonctionne.', { modelTier: 'default', cache: false });
    const phrase = String((r && r.phrase) || '').slice(0, 200) || '(réponse vide)';
    reponse.textContent = phrase;
    if (db) { await db.collection('essais').doc('e' + Date.now().toString(36)).set({ phrase: phrase, createdAt: Date.now() }); }
  } catch (e) { reponse.textContent = "L'appel à Claude a échoué."; }
  bouton.disabled = false;
});
